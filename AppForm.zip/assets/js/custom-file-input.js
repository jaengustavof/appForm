/*
	By Osvaldas Valutis, www.osvaldas.info
	Available for use under the MIT License
*/

'use strict';

;( function ( document, window, index )
{
	var inputs = document.querySelectorAll( '.inputfile' );
	Array.prototype.forEach.call( inputs, function( input )
	{
		var label	 = input.nextElementSibling,
			labelVal = label.innerHTML;

		input.addEventListener( 'change', function( e )
		{
			var fileName = e.target.value.split( '\\' ).pop();

			var salesForceFile = document.getElementById("00N3t00000GCGiP");

			if( fileName ){
				label.querySelector( 'span' ).innerHTML = fileName;
				salesForceFile.setAttribute("value", "http://localhost/appform/uploads/"+fileName);
				console.log(fileName);
				console.log("sales "+salesForceFile.value);
			}

			else{
				label.innerHTML = labelVal;
			}
		});

		// Firefox bug fix
		input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
		input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
	});
}( document, window, 0 ));