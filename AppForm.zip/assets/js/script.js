$(document).ready(function(){
 
   /*      $('.authorizationButton').click(function(){
            var nombre = $("#authorization").prop('checked');
                 if (nombre == true){
                    $('.authorizationButton').css('background', 'white');
                    $('.authorizationButtonP').css('color', '#6898bd');
                    $('.authorizationButtonP').html('X');
                    document.getElementById("send").style.display = "none";
                }else {
                    $('.authorizationButton').css('background', 'green');
                    $('.authorizationButtonP').css('color', 'white');
                    $('.authorizationButtonP').html('I accept');
                    document.getElementById("send").style.display = "flex";
    
                }

                console.log(nombre);           
            });*/
$(":input").inputmask();

$("#phone").inputmask({"mask": "(999) 999-9999"});

});



var currentTab = 0; // Current tab is set to be the first tab (0)
    var currentRight = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab
     showTab(currentRight); // Display the current tab
console.log(currentTab);

    function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("appFormContent");
  var y = document.getElementsByClassName("right");
 // var authorization = document.getElementById("authorization").value;
  x[n].style.display = "flex";
  y[n].style.display = "flex";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "flex";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").style.display = "none";
     /*document.getElementById("but_upload").style.display = "flex";*/
   
    
  } else {
    document.getElementById("nextBtn").style.display = "flex";
    document.getElementById("but_upload").style.display = "none";
  }
  //... and run a function that will display the correct step indicator:
 
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("appFormContent");
  var y = document.getElementsByClassName("right");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  y[currentRight].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  currentRight = currentRight +n;
  // if you have reached the end of the form...
  if (currentTab >= x.length && currentRight>= y.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }

  // Otherwise, display the correct tab:
  showTab(currentTab);
}



function validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}


function validatePhone(phone) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    var phone = document.getElementById("phone");
        if(phone.value.match(phoneno)) {
            return true;
        }else {
            return false;
        }            
}

var email = document.getElementById("email");
var phone = document.getElementById("phone");
var select = document.getElementById("00N3t00000GC44w");

function validateForm() {
  // This function deals with validation of the form fields
  var emailValidation = validateEmail(email.value);
  var phoneValidation = validatePhone(phone.value);
  var x, y, i, valid = true;
  x = document.getElementsByClassName("appFormContent");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 2; i < y.length; i++) {

    if (!emailValidation) {
       y[3].className += " invalid"; 
       valid = false;
    }

    if(!phoneValidation){
        y[4].className += " invalid"; 
        valid = false;
    }
    // If a field is empty...
    if (y[i].value == "") {

      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
      
    }

  }

  if(currentTab == 2){
    if(select.value == ""){
      select.className += " invalid";
      valid = false;
      select.after(`

        Please, choose an option. 

      `)
    }
  }

  if(currentTab == 3){
    
      $("#file5").change(function(){
        var imagen = this.files[0];
        if(imagen["type"] != "image/jpeg" && imagen["type"] != "image/png"){
        $("#file5").after(``);
        $("#file5").val("");
        valid = false;
        $("#file5").after(`
            Image must be .jpg or .png format

              `)
        return;
        }else if(imagen["size"] > 2000000){
          valid = false;
          $("#file5").after(`

              Image size must be less than 2MB 

            `)
          return;
        }

      });
  }

   
    

  // If the valid status is true, mark the step as finished and valid:
  return valid; // return the valid status
}


/**********************************************/

  var check;
      $('#checkB').click(function(){
      check = $("#checkB").prop('checked')
      if(check == false){
        $("#but_upload").css('display', "none");
      }else if(check == true){
        $("#but_upload").css('display', "flex");
      }

        
        /*check = $("#checkB").prop('checked');
        if (check == true){
            $("#but_upload").css('display', 'flex!important');
        }else if (check == false){
            $("#but_upload").css('display', 'none!important');
        }*/
      });

/*****************************/

